from django.contrib import admin
from learning_paths.models import LearningPath
@admin.register(LearningPath)
class LearningPathAdmin(admin.ModelAdmin):
    list_display = ('title', 'goal', 'created_at','is_public')
    search_fields = ('title', 'goal','skils__name')
    list_filter = ('created_at','is_public')
    #@staticmethod
    #def get_queryset(request):
    #    return LearningPath.objects.prefetch_related('skils')

