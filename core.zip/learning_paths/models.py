from django.db import models
from core.models import Requerment
from django.utils.text import slugify
from skills.models import Skill
class LearningPath(Requerment):
    title = models.CharField(max_length=255)
    slug = models.SlugField(unique=True, blank=True, editable=False)
    goal = models.TextField()
    skils = models.ManyToManyField(Skill, related_name='learning_paths')
    is_public = models.BooleanField(default=False)
    def __str__(self):
        return f'{self.title} - {self.goal}'
    def save(self, *args, **kwargs):
        self.slug = slugify(f'{self.title} - {self.pk}')
        super().save(*args, **kwargs)
