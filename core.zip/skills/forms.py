from django import forms
from skills.models import Category,Skill
class FormCategory(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['created_at'].disabled = True
        self.fields['slug'].disabled = True
        self.fields['updated_at'].disabled = True
    class Meta:
        model = Category
        exclude = ('slug','updated_at')
    help_text = {
        'name':'Give the category a name.',
        'description':'Describe the category(is optional)'}
    error_messages = {
            'name':{'max_length':'The title max_contains 100 letters','required':'This is required!',
                    'unique':'The category already exists'},
        }
class FormSkill(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['created_at'].disabled = True
        self.fields['slug'].disabled = True
        self.fields['updated_at'].disabled = True
    class Meta:
        model = Skill
        exclude = ('slug','updated_at')
        