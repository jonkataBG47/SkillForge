from django.shortcuts import render
from skills.models import Category,Skill
from django.db.models import Count
from django.shortcuts import get_object_or_404
def categories_list(request):
    categories = Category.objects.annotate(count_skills=Count('skills')).order_by('-count_skills','name')
    context = {'categories': categories}
    return render(request, 'skills/category_list.html', context)
def categories_detail(request, slug):
    category = get_object_or_404(Category, slug=slug)
    skills = category.skills.all().order_by('title')
    context = {'category': category, 'skills': skills}
    return render(request, 'skills/category_detail.html', context)
def skill_list(request):
    Skills = Skill.objects.all().order_by('title')
    context = {'skills': Skills}
    return render(request, 'skills/skill_list.html', context)
def skill_detail(request, slug):
    skill = get_object_or_404(Skill.objects.prefetch_related('resources'), slug=slug)
    context = {'skill': skill}
    return render(request, 'skills/skill_detail.html', context)