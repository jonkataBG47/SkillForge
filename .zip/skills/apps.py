from django.apps import AppConfig


class SkillsConfig(AppConfig):
    name = 'skills'
