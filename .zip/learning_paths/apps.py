from django.apps import AppConfig


class LearningPathsConfig(AppConfig):
    name = 'learning_paths'
